import { useState, useEffect } from "react";
import { useTelegram } from "@/hooks/useTelegram";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MarketAsset } from "@/types/crypto";
import { ArrowLeftIcon, SearchIcon, TrendingUpIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomNavigation from "@/components/BottomNavigation";
import { TRENDING_ASSETS } from "@/data/trendingAssets";

const mockTrendingAssets: MarketAsset[] = [
  {
    id: "cati",
    symbol: "CATI",
    name: "CATI",
    price: 0.0813,
    change24h: 3.16,
    marketCap: 81300000,
    icon: "🐱",
    sparkline: [0.078, 0.079, 0.081, 0.0813],
  },
  {
    id: "xtz",
    symbol: "XTZ",
    name: "XTZ",
    price: 0.536,
    change24h: 3.2,
    marketCap: 536000000,
    icon: "🔷",
    sparkline: [0.52, 0.525, 0.53, 0.536],
  },
];

const mockTopAssets: MarketAsset[] = [
  {
    id: "btc",
    symbol: "BTC",
    name: "Bitcoin",
    price: 109008.18,
    change24h: 1.09,
    marketCap: 2150000000000,
    icon: "₿",
    sparkline: [108000, 108500, 109000, 109008],
  },
  {
    id: "eth",
    symbol: "ETH",
    name: "Ethereum",
    price: 2620.19,
    change24h: 3.52,
    marketCap: 315000000000,
    icon: "Ξ",
    sparkline: [2530, 2580, 2610, 2620],
  },
  {
    id: "usdt",
    symbol: "USDT",
    name: "Доллары",
    price: 1.0,
    change24h: 0.02,
    marketCap: 140000000000,
    icon: "💵",
    sparkline: [1.0, 1.0, 1.0, 1.0],
  },
  {
    id: "xrp",
    symbol: "XRP",
    name: "XRP",
    price: 2.313,
    change24h: 0.94,
    marketCap: 132000000000,
    icon: "🔷",
    sparkline: [2.28, 2.29, 2.31, 2.313],
  },
  {
    id: "sol",
    symbol: "SOL",
    name: "Solana",
    price: 152.47,
    change24h: 1.67,
    marketCap: 72000000000,
    icon: "🌅",
    sparkline: [150, 151, 152, 152.47],
  },
];

export default function Market() {
  const { tg, hapticFeedback } = useTelegram();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<
    "all" | "ton" | "growth" | "decline"
  >("all");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (tg) {
      tg.BackButton.show();
      const handleBack = () => {
        hapticFeedback("light");
        navigate("/");
      };
      tg.BackButton.onClick(handleBack);

      return () => {
        tg.BackButton.offClick(handleBack);
      };
    }
  }, [tg, navigate, hapticFeedback]);

  const handleAssetClick = (asset: MarketAsset) => {
    hapticFeedback("medium");
    navigate(`/coin/${asset.id}`);
  };

  const formatMarketCap = (marketCap: number) => {
    if (marketCap >= 1000000000) {
      return `${(marketCap / 1000000000).toFixed(1)}B`;
    } else if (marketCap >= 1000000) {
      return `${(marketCap / 1000000).toFixed(1)}M`;
    }
    return marketCap.toString();
  };

  const MiniSparkline = ({ data }: { data: number[] }) => {
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min;

    return (
      <svg width="40" height="20" className="text-success">
        <polyline
          points={data
            .map((point, index) => {
              const x = (index / (data.length - 1)) * 40;
              const y = 20 - ((point - min) / range) * 20;
              return `${x},${y}`;
            })
            .join(" ")}
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
        />
      </svg>
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Empty Header */}
      <div className="h-[17px] sm:h-16 p-4"></div>

      {/* Search */}
      <div className="px-4 mb-6">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Поиск"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Trending Section */}
      <div className="px-4 mb-6">
        <h2 className="text-lg font-semibold mb-4 text-muted-foreground">
          В ТРЕНДЕ
        </h2>

        <div
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 snap-x snap-mandatory touch-pan-x"
          style={{ WebkitOverflowScrolling: "touch" }}
        >
          {TRENDING_ASSETS.map((asset) => (
            <Card
              key={asset.id}
              className="p-4 hover:bg-muted/50 transition-colors cursor-pointer w-[calc(50vw-24px)] flex-shrink-0 snap-start"
              onClick={() =>
                handleAssetClick({
                  id: asset.id,
                  symbol: asset.symbol,
                  name: asset.name,
                  price: asset.price,
                  change24h: asset.change24h,
                  marketCap: 0,
                  icon: asset.icon,
                  sparkline: [0.95, 0.97, 0.99, 1.01],
                })
              }
            >
              <div className="flex items-center justify-between mb-4">
                <div
                  className={`w-12 h-12 ${asset.iconBgColor} rounded-full flex items-center justify-center`}
                >
                  <span className="text-white text-xl font-bold">
                    {asset.icon}
                  </span>
                </div>
                <div className="w-16 h-8">
                  <svg width="64" height="32" className="text-success">
                    <polyline
                      points="0,24 16,20 32,16 48,12 64,8"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
              </div>
              <div>
                <div className="font-bold text-lg mb-1">{asset.symbol}</div>
                <div className="text-success text-base mb-2">
                  ↑ {asset.change24h.toFixed(2)}%
                </div>
                <div className="text-base font-semibold">
                  {asset.price.toLocaleString()} $
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Top Assets Section */}
      <div className="px-4">
        <h2 className="text-lg font-semibold mb-4 text-muted-foreground">
          ТОП ДНЯ
        </h2>

        {/* Tabs */}
        <div className="flex space-x-6 mb-4 overflow-x-auto">
          {[
            { key: "all", label: "Все" },
            { key: "ton", label: "Активы TON" },
            { key: "growth", label: "Топ роста" },
            { key: "decline", label: "Топ пад" },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key as any);
                hapticFeedback("light");
              }}
              className={`pb-2 border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab.key
                  ? "border-primary text-primary font-medium"
                  : "border-transparent text-muted-foreground"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Assets List */}
        <div className="space-y-2">
          {mockTopAssets.map((asset, index) => (
            <Card
              key={asset.id}
              className="p-4 hover:bg-muted/50 transition-colors cursor-pointer"
              onClick={() => handleAssetClick(asset)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                    <span className="text-lg">{asset.icon}</span>
                  </div>
                  <div>
                    <div className="font-medium">{asset.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {asset.symbol}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">
                    {asset.price.toLocaleString("en-US", {
                      style: "currency",
                      currency: "USD",
                    })}
                  </div>
                  <div
                    className={`text-sm ${
                      asset.change24h >= 0 ? "text-success" : "text-destructive"
                    }`}
                  >
                    {asset.change24h >= 0 ? "↑" : "↓"}
                    {Math.abs(asset.change24h).toFixed(2)}%
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
