import { useState, useEffect } from "react";
import { useTelegram } from "@/hooks/useTelegram";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeftIcon } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { TRENDING_ASSETS } from "@/data/trendingAssets";

// Mock chart data for Hedera
const mockChartData = [
  { time: "10:00", price: 0.159 },
  { time: "11:00", price: 0.158 },
  { time: "12:00", price: 0.157 },
  { time: "13:00", price: 0.159 },
  { time: "14:00", price: 0.161 },
  { time: "15:00", price: 0.163 },
  { time: "16:00", price: 0.165 },
  { time: "17:00", price: 0.168 },
  { time: "18:00", price: 0.17 },
  { time: "19:00", price: 0.172 },
];

export default function CoinDetail() {
  const { tg, hapticFeedback } = useTelegram();
  const navigate = useNavigate();
  const { coinId } = useParams();
  const [timeRange, setTimeRange] = useState("1D");

  // Find the asset based on coinId
  const asset = TRENDING_ASSETS.find((a) => a.id === coinId) || {
    id: "hedera",
    symbol: "HBAR",
    name: "Hedera",
    price: 0.172,
    change24h: 6.48,
    icon: "H",
    iconBgColor: "bg-foreground",
  };

  useEffect(() => {
    if (tg) {
      tg.BackButton.show();
      const handleBack = () => {
        hapticFeedback("light");
        navigate(-1);
      };
      tg.BackButton.onClick(handleBack);

      return () => {
        tg.BackButton.offClick(handleBack);
      };
    }
  }, [tg, navigate, hapticFeedback]);

  const SimpleChart = () => {
    const maxPrice = Math.max(...mockChartData.map((d) => d.price));
    const minPrice = Math.min(...mockChartData.map((d) => d.price));
    const priceRange = maxPrice - minPrice;

    return (
      <div className="h-48 w-full relative">
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 400 200"
          className="absolute inset-0"
        >
          {/* Grid lines */}
          {[0.16, 0.165, 0.17].map((price, i) => {
            const y = 200 - ((price - minPrice) / priceRange) * 180 + 10;
            return (
              <g key={i}>
                <line
                  x1="0"
                  y1={y}
                  x2="400"
                  y2={y}
                  stroke="hsl(var(--muted))"
                  strokeWidth="0.5"
                  opacity="0.3"
                />
                <text
                  x="380"
                  y={y - 5}
                  fontSize="10"
                  fill="hsl(var(--muted-foreground))"
                >
                  {price.toFixed(3)}
                </text>
              </g>
            );
          })}

          {/* Chart line */}
          <polyline
            points={mockChartData
              .map((point, index) => {
                const x = (index / (mockChartData.length - 1)) * 380 + 10;
                const y =
                  200 - ((point.price - minPrice) / priceRange) * 180 + 10;
                return `${x},${y}`;
              })
              .join(" ")}
            fill="none"
            stroke="hsl(var(--success))"
            strokeWidth="2"
          />

          {/* Chart fill */}
          <polygon
            points={`10,190 ${mockChartData
              .map((point, index) => {
                const x = (index / (mockChartData.length - 1)) * 380 + 10;
                const y =
                  200 - ((point.price - minPrice) / priceRange) * 180 + 10;
                return `${x},${y}`;
              })
              .join(" ")} 390,190`}
            fill="url(#gradient)"
            opacity="0.1"
          />

          {/* Gradient definition */}
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="hsl(var(--success))" />
              <stop offset="100%" stopColor="transparent" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-primary"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </Button>
          <span className="text-primary">Назад</span>
        </div>
        <div className="text-center">
          <h1 className="font-semibold">Гаманець ✓</h1>
          <p className="text-sm text-muted-foreground">мініЗастосунок</p>
        </div>
        <Button variant="ghost" size="icon">
          <div className="w-5 h-5 flex items-center justify-center">⋯</div>
        </Button>
      </div>

      {/* Warning Message */}
      <div className="p-4 bg-muted/20">
        <p className="text-sm text-muted-foreground text-center">
          Сейчас Hedera можно только купить, продать или хранить в Кошельке.
          Перевести, получить или вывести Hedera не получится.
        </p>
      </div>

      {/* Coin Info */}
      <div className="p-4">
        <Card className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold">{asset.name}</h2>
              <div className="flex items-center gap-4 mt-2">
                <span className="text-success text-sm">
                  ↑ {asset.change24h.toFixed(2)}%
                </span>
                <span className="text-success text-sm">
                  +{((asset.price * asset.change24h) / 100).toFixed(4)} $
                </span>
                <span className="text-muted-foreground text-sm">Сегодня</span>
              </div>
            </div>
            <div
              className={`w-12 h-12 ${asset.iconBgColor} rounded-full flex items-center justify-center text-white font-bold text-xl`}
            >
              {asset.icon}
            </div>
          </div>

          <div className="text-3xl font-bold mb-4">
            {asset.price.toLocaleString()} $
          </div>

          {/* Chart */}
          <SimpleChart />

          {/* Time Range Buttons */}
          <div className="flex gap-2 mt-4">
            {["1Д", "7Д", "1М", "1Г", "Все"].map((range) => (
              <Button
                key={range}
                variant={timeRange === range ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setTimeRange(range);
                  hapticFeedback("light");
                }}
                className="text-xs"
              >
                {range}
              </Button>
            ))}
          </div>
        </Card>
      </div>

      {/* About Section */}
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-3 text-muted-foreground">
          О КРИПТОВАЛЮТЕ
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          Hedera запустили в 2018 году. Вместо блокчейна она использует
          технологию hashgraph — данные записывают{" "}
          <span className="text-primary">Подробнее</span>
        </p>

        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-muted-foreground rounded-full mt-2 flex-shrink-0" />
            <p className="text-sm text-muted-foreground">
              Вы можете только поку��ать, продавать или хранить HBAR в Кошельке.
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-4 space-y-3">
        <Button
          className="w-full bg-primary text-primary-foreground"
          onClick={() => hapticFeedback("medium")}
        >
          Купить
        </Button>
        <Button
          variant="outline"
          className="w-full"
          onClick={() => hapticFeedback("medium")}
        >
          Продать
        </Button>
      </div>
    </div>
  );
}
