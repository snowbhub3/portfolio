import { useState, useEffect } from "react";
import { useTelegram } from "@/hooks/useTelegram";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Transaction } from "@/types/crypto";
import {
  ArrowLeftIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  RefreshCwIcon,
  GiftIcon,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomNavigation from "@/components/BottomNavigation";

const mockTransactions: Transaction[] = [
  {
    id: "1",
    type: "send",
    asset: "USDT",
    amount: 4.98,
    usdValue: 4.98,
    status: "completed",
    timestamp: new Date("2024-12-06T16:30:00"),
    description: "Продажа: P2P",
    icon: "💵",
  },
  {
    id: "2",
    type: "receive",
    asset: "USDT",
    amount: 4.98,
    usdValue: 4.98,
    status: "completed",
    timestamp: new Date("2024-12-06T16:24:00"),
    description: "Обмен: BTC на USDT",
    icon: "💵",
  },
  {
    id: "3",
    type: "receive",
    asset: "BTC",
    amount: 0.0000509,
    usdValue: 5.55,
    status: "completed",
    timestamp: new Date("2024-11-16T00:00:00"),
    description: "Обмен: TON на BTC",
    icon: "₿",
  },
  {
    id: "4",
    type: "bonus",
    asset: "TON",
    amount: 0.3467,
    usdValue: 0.97,
    status: "completed",
    timestamp: new Date("2024-10-28T05:00:00"),
    description: "Получено: Бонус��",
    icon: "🎁",
  },
  {
    id: "5",
    type: "send",
    asset: "USDT",
    amount: 49.59,
    usdValue: 49.59,
    status: "completed",
    timestamp: new Date("2024-08-15T17:21:00"),
    description: "Продажа: P2P",
    icon: "💵",
  },
];

export default function History() {
  const { tg, hapticFeedback } = useTelegram();
  const navigate = useNavigate();

  useEffect(() => {
    if (tg) {
      tg.BackButton.show();
      const handleBack = () => {
        hapticFeedback("light");
        navigate("/");
      };
      tg.BackButton.onClick(handleBack);

      return () => {
        tg.BackButton.offClick(handleBack);
      };
    }
  }, [tg, navigate, hapticFeedback]);

  const getTransactionIcon = (transaction: Transaction) => {
    switch (transaction.type) {
      case "send":
        return <ArrowUpIcon className="w-5 h-5 text-destructive" />;
      case "receive":
        return <ArrowDownIcon className="w-5 h-5 text-success" />;
      case "exchange":
        return <RefreshCwIcon className="w-5 h-5 text-primary" />;
      case "bonus":
        return <GiftIcon className="w-5 h-5 text-warning" />;
      default:
        return <ArrowUpIcon className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-success";
      case "pending":
        return "text-warning";
      case "failed":
        return "text-destructive";
      default:
        return "text-muted-foreground";
    }
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / 60000);

    if (diffInMinutes < 60) {
      return `${diffInMinutes} мин. назад`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours} ч. назад`;
    } else {
      return date.toLocaleDateString("ru-RU", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Empty Header */}
      <div className="h-16 p-4"></div>

      {/* Transactions */}
      <div className="px-4">
        <h2 className="text-lg font-semibold mb-4 text-muted-foreground">
          ИСТОРИЯ ТРАНЗАКЦИЙ
        </h2>
        <div className="space-y-2">
          {mockTransactions.map((transaction) => (
            <Card
              key={transaction.id}
              className="p-4 hover:bg-muted/50 transition-colors cursor-pointer"
              onClick={() => hapticFeedback("light")}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    {getTransactionIcon(transaction)}
                  </div>
                  <div>
                    <div className="font-medium">{transaction.description}</div>
                    <div className="text-sm text-muted-foreground">
                      {formatDate(transaction.timestamp)}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={`font-medium ${
                      transaction.type === "receive" ||
                      transaction.type === "bonus"
                        ? "text-success"
                        : "text-destructive"
                    }`}
                  >
                    {transaction.type === "receive" ||
                    transaction.type === "bonus"
                      ? "+"
                      : "-"}
                    {transaction.amount} {transaction.asset}
                  </div>
                  <div
                    className={`text-sm ${getStatusColor(transaction.status)}`}
                  >
                    {transaction.status === "completed"
                      ? "Отправлено"
                      : transaction.status === "pending"
                        ? "В обработке"
                        : "Ошибка"}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
