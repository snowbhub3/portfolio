import { useState, useEffect } from "react";
import { useTelegram } from "@/hooks/useTelegram";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ArrowLeftIcon,
  BellIcon,
  FingerprintIcon,
  GlobeIcon,
  DollarSignIcon,
  CreditCardIcon,
  HelpCircleIcon,
  MessageSquareIcon,
  LightbulbIcon,
  ChevronRightIcon,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const settingsItems = [
  {
    icon: <BellIcon className="w-5 h-5 text-red-500" />,
    title: "Уведомления",
    value: "",
    hasChevron: true,
  },
  {
    icon: <FingerprintIcon className="w-5 h-5 text-green-500" />,
    title: "Код-пароль и Face ID",
    value: "Вкл",
    hasChevron: true,
  },
  {
    icon: <GlobeIcon className="w-5 h-5 text-purple-500" />,
    title: "Язык",
    value: "Русский",
    hasChevron: true,
  },
  {
    icon: <DollarSignIcon className="w-5 h-5 text-gray-500" />,
    title: "Основная валюта",
    value: "USD",
    hasChevron: true,
  },
];

const walletTabs = [
  { id: "wallet", label: "Кошелёк", active: true },
  { id: "tonspace", label: "TON Space", error: true },
];

const supportItems = [
  {
    icon: <CreditCardIcon className="w-5 h-5 text-blue-500" />,
    title: "Уровень верификации",
    value: "Макси",
    hasChevron: true,
  },
  {
    icon: <MessageSquareIcon className="w-5 h-5 text-orange-500" />,
    title: "Обратиться в поддержку",
    hasChevron: true,
  },
  {
    icon: <HelpCircleIcon className="w-5 h-5 text-blue-400" />,
    title: "FAQ Кошелька",
    hasChevron: true,
  },
  {
    icon: <LightbulbIcon className="w-5 h-5 text-yellow-500" />,
    title: "Новости Кошелька",
    hasChevron: true,
  },
];

export default function Settings() {
  const { tg, hapticFeedback } = useTelegram();
  const navigate = useNavigate();

  useEffect(() => {
    if (tg) {
      tg.BackButton.show();
      const handleBack = () => {
        hapticFeedback("light");
        navigate("/");
      };
      tg.BackButton.onClick(handleBack);

      return () => {
        tg.BackButton.offClick(handleBack);
      };
    }
  }, [tg, navigate, hapticFeedback]);

  const handleItemClick = (item: any) => {
    hapticFeedback("light");
    console.log(`Clicked: ${item.title}`);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-primary"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </Button>
          <span className="text-primary">Назад</span>
        </div>
        <div className="text-center">
          <h1 className="font-semibold">Гаманець ✓</h1>
          <p className="text-sm text-muted-foreground">мініЗастосунок</p>
        </div>
        <Button variant="ghost" size="icon">
          <div className="w-5 h-5 flex items-center justify-center">⋯</div>
        </Button>
      </div>

      <div className="p-4">
        {/* Basic Settings */}
        <h2 className="text-lg font-semibold mb-4 text-muted-foreground">
          ОСНОВНЫЕ НАСТРОЙКИ
        </h2>
        <Card className="mb-6">
          {settingsItems.map((item, index) => (
            <div
              key={index}
              className={`p-4 flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors ${
                index !== settingsItems.length - 1
                  ? "border-b border-border"
                  : ""
              }`}
              onClick={() => handleItemClick(item)}
            >
              <div className="flex items-center gap-3">
                {item.icon}
                <span className="font-medium">{item.title}</span>
              </div>
              <div className="flex items-center gap-2">
                {item.value && (
                  <span className="text-muted-foreground">{item.value}</span>
                )}
                {item.hasChevron && (
                  <ChevronRightIcon className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
            </div>
          ))}
        </Card>

        {/* Wallet Tabs */}
        <div className="flex gap-2 mb-4">
          {walletTabs.map((tab) => (
            <Button
              key={tab.id}
              variant={tab.active ? "default" : "outline"}
              className={`flex-1 relative ${tab.error ? "border-destructive" : ""}`}
              onClick={() => hapticFeedback("light")}
            >
              {tab.label}
              {tab.error && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full flex items-center justify-center">
                  <span className="text-destructive-foreground text-xs">!</span>
                </div>
              )}
            </Button>
          ))}
        </div>

        {/* Verification Notice */}
        <Card className="p-4 mb-6">
          <div className="flex items-center gap-3">
            <CreditCardIcon className="w-5 h-5 text-blue-500" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="font-medium">Уровень верификации</span>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">Макси</span>
                  <ChevronRightIcon className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Не распространяется на аккаунт TON Space.
          </p>
        </Card>

        {/* Support Items */}
        <Card className="mb-6">
          {supportItems.slice(1).map((item, index) => (
            <div
              key={index}
              className={`p-4 flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors ${
                index !== supportItems.slice(1).length - 1
                  ? "border-b border-border"
                  : ""
              }`}
              onClick={() => handleItemClick(item)}
            >
              <div className="flex items-center gap-3">
                {item.icon}
                <span className="font-medium">{item.title}</span>
              </div>
              <div className="flex items-center gap-2">
                {item.value && (
                  <span className="text-muted-foreground">{item.value}</span>
                )}
                {item.hasChevron && (
                  <ChevronRightIcon className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
            </div>
          ))}
        </Card>

        {/* Legal Links */}
        <div className="space-y-3 mb-6">
          <Button
            variant="ghost"
            className="w-full justify-start text-primary p-0"
            onClick={() => hapticFeedback("light")}
          >
            Пользовательское соглашение
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start text-primary p-0"
            onClick={() => hapticFeedback("light")}
          >
            Политика конфиденциальности
          </Button>
        </div>

        {/* Footer */}
        <div className="text-center text-sm text-muted-foreground">
          <p className="mb-1">Мини-приложение управляется TG Wallet Inc.</p>
          <p className="mb-1">Сервис независим и не связан с Telegram.</p>
          <Button
            variant="ghost"
            className="text-primary p-0 h-auto"
            onClick={() => hapticFeedback("light")}
          >
            Узнать больше
          </Button>
        </div>
      </div>
    </div>
  );
}
