import { useEffect, useState } from "react";

export const useTelegram = () => {
  const [webApp, setWebApp] = useState<typeof window.Telegram.WebApp | null>(
    null,
  );
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    if (window?.Telegram?.WebApp) {
      const tg = window.Telegram.WebApp;
      setWebApp(tg);
      setUser(tg.initDataUnsafe?.user);

      tg.ready();
      tg.expand();
    }
  }, []);

  const hapticFeedback = (type: "light" | "medium" | "heavy" = "medium") => {
    webApp?.HapticFeedback?.impactOccurred(type);
  };

  const showMainButton = (text: string, onClick: () => void) => {
    if (webApp?.MainButton) {
      webApp.MainButton.setText(text);
      webApp.MainButton.show();
      webApp.MainButton.onClick(onClick);
    }
  };

  const hideMainButton = () => {
    webApp?.MainButton?.hide();
  };

  return {
    webApp,
    user,
    hapticFeedback,
    showMainButton,
    hideMainButton,
    tg: webApp,
  };
};
