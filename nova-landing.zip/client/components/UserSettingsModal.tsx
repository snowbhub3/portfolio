import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  BellIcon,
  FingerprintIcon,
  GlobeIcon,
  DollarSignIcon,
  CreditCardIcon,
  HelpCircleIcon,
  FileTextIcon,
  LightbulbIcon,
  ChevronRightIcon,
  XIcon,
} from "lucide-react";
import { useTelegram } from "@/hooks/useTelegram";

interface UserSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const settingsItems = [
  {
    icon: <BellIcon className="w-5 h-5 text-red-500" />,
    title: "Сповіщення",
    hasChevron: true,
  },
  {
    icon: <FingerprintIcon className="w-5 h-5 text-green-500" />,
    title: "Код пароль",
    hasChevron: true,
  },
  {
    icon: <GlobeIcon className="w-5 h-5 text-purple-500" />,
    title: "Мова",
    hasChevron: true,
  },
  {
    icon: <DollarSignIcon className="w-5 h-5 text-gray-500" />,
    title: "Основна валюта",
    hasChevron: true,
  },
  {
    icon: <CreditCardIcon className="w-5 h-5 text-blue-500" />,
    title: "Рівень Верифікації",
    hasChevron: true,
  },
  {
    icon: <HelpCircleIcon className="w-5 h-5 text-blue-400" />,
    title: "Підтримка",
    hasChevron: true,
  },
  {
    icon: <FileTextIcon className="w-5 h-5 text-orange-500" />,
    title: "Документація",
    hasChevron: true,
  },
  {
    icon: <LightbulbIcon className="w-5 h-5 text-yellow-500" />,
    title: "Новини",
    hasChevron: true,
  },
];

export default function UserSettingsModal({
  isOpen,
  onClose,
}: UserSettingsModalProps) {
  const { hapticFeedback } = useTelegram();

  if (!isOpen) return null;

  const handleItemClick = (item: any) => {
    hapticFeedback("light");
    console.log(`Clicked: ${item.title}`);
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-lg w-full max-w-md max-h-[80vh] overflow-y-auto border border-border">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-semibold">Налаштування</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <XIcon className="w-5 h-5" />
          </Button>
        </div>

        {/* Settings Items */}
        <div className="p-4">
          <Card>
            {settingsItems.map((item, index) => (
              <div
                key={index}
                className={`p-4 flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors ${
                  index !== settingsItems.length - 1
                    ? "border-b border-border"
                    : ""
                }`}
                onClick={() => handleItemClick(item)}
              >
                <div className="flex items-center gap-3">
                  {item.icon}
                  <span className="font-medium">{item.title}</span>
                </div>
                {item.hasChevron && (
                  <ChevronRightIcon className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
            ))}
          </Card>

          {/* Legal Links */}
          <div className="mt-6 space-y-3">
            <Button
              variant="ghost"
              className="w-full justify-start text-primary p-0"
              onClick={() => hapticFeedback("light")}
            >
              Погодження користувача
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start text-primary p-0"
              onClick={() => hapticFeedback("light")}
            >
              Політика конфіденційності
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
